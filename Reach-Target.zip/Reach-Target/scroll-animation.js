// Scroll Animation Script

document.addEventListener('DOMContentLoaded', function() {
  // Select all elements with animation classes
  const animatedElements = document.querySelectorAll('.fade-in, .slide-left, .slide-right, .slide-up, .scale-in, .rotate-in');

  // Create Intersection Observer
  const observerOptions = {
    threshold: 0.1, // Trigger when 10% of element is visible
    rootMargin: '0px 0px -50px 0px' // Trigger slightly before element enters viewport
  };

  const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('show');
        // Stop observing once animated
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  // Observe each animated element
  animatedElements.forEach(element => {
    observer.observe(element);
  });
});
